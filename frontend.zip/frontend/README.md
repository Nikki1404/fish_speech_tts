# Ghost Denials Frontend

React + Vite frontend for uploading CSV files to the FastAPI audit service and
displaying the real analysis response.

## Environment

Create a local `.env` file from `.env.example`:

```bash
VITE_API_BASE_URL=http://localhost:8000
```

Point it at whatever port the backend is actually on. You can also override it
for a single run without editing the file:

```bash
VITE_API_BASE_URL=http://localhost:8001 npm run dev
```

## Run

```bash
npm install
npm run dev
```

The app runs on `http://localhost:5173` by default. If that port is taken Vite
walks forward to 5174, 5175, … — the backend's CORS list allows those fallbacks,
so a bumped port still works. Pin it with `npm run dev -- --port 5173 --strictPort`
if you would rather fail loudly than move.

## Backend

Start the FastAPI service from `ghost_denials_fastapi` first:

```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```

## Uploading CSVs

Any claims CSV works — column names and status wording do **not** have to match
the bundled dataset. The backend infers which column holds the unique identifier,
which holds the claim status and which holds the reason, then reports its
interpretation back in `schema_report`.

The results panel reacts to that report:

| Backend `mode` | What you see |
| --- | --- |
| `strict` | No banner. The file already matched the canonical schema. |
| `adapted` | Amber **Schema adapted** banner listing the detected identifier column, status column, which values were read as approved vs denied, and any warnings. |
| `insufficient` | Violet **Could not analyze** banner with the reason, and empty result lists. Still an HTTP 200, not an error state. |

Result tables are labelled with the identifier column name from *your* file — a
CSV whose IDs live in `Claim Number` gets a `Denied Claim Number` header rather
than `Denied VisitID#`.

## Test data

| File | What it exercises |
| --- | --- |
| `ghost_denials_fastapi/claims.csv` | the canonical schema — runs in `strict` mode, no banner |
| `ghost_denials_fastapi/sample_csvs/variant_a_payer_export.csv` | every column renamed, `Paid`/`Rejected` wording, `$1,234.50` amounts |
| `ghost_denials_fastapi/sample_csvs/variant_b_minimal.csv` | ID + status + amount only — adapts, but raises several precision warnings |
| `ghost_denials_fastapi/sample_csvs/variant_c_messy.csv` | semicolon-delimited, BOM, preamble rows, `dd/mm/yyyy` dates, `000000041` IDs |
| `ghost_denials_fastapi/sample_csvs/variant_d_denials_only.csv` | denials with no approved rows — shows the blocked banner |

Variants A and C describe the same 200 claims through very different schemas and
return identical results.

## Types

`src/types/api.ts` mirrors the backend response. `schema_report` is optional, so
the app still compiles and renders against a backend that does not send it.

## Build

```bash
npm run build     # tsc -b && vite build
npm run preview   # serve dist/ on 4173
```
