import { extractBackendErrorMessage } from '../utils/error';
import type { AuditResponse, UploadAuditCsvOptions } from '../types/api';

class ApiError extends Error {
  status: number;

  constructor(status: number, message: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

function getApiBaseUrl(): string {
  const baseUrl = import.meta.env.VITE_API_BASE_URL?.trim();
  if (!baseUrl) {
    throw new Error('Missing VITE_API_BASE_URL. Set it in frontend/.env.');
  }

  return baseUrl.replace(/\/+$/, '');
}

async function readErrorPayload(response: Response): Promise<unknown> {
  const contentType = response.headers.get('content-type') || '';

  if (contentType.includes('application/json')) {
    try {
      return await response.json();
    } catch {
      return null;
    }
  }

  try {
    return await response.text();
  } catch {
    return null;
  }
}

export async function uploadAuditCsv(
  file: File,
  options: UploadAuditCsvOptions,
): Promise<AuditResponse> {
  const baseUrl = getApiBaseUrl();
  const formData = new FormData();

  formData.append('file', file);
  formData.append(
    'logistic_caliper_multiplier',
    String(options.logisticCaliperMultiplier),
  );
  formData.append('knn_control_quantile', String(options.knnControlQuantile));

  if (typeof options.maxItems === 'number' && Number.isFinite(options.maxItems)) {
    formData.append('max_items', String(options.maxItems));
  }

  let response: Response;
  try {
    response = await fetch(`${baseUrl}/audit/upload`, {
      method: 'POST',
      body: formData,
      headers: {
        Accept: 'application/json',
      },
    });
  } catch {
    throw new Error('Unable to connect to the analysis service. Please check that the backend is running and try again.');
  }

  if (!response.ok) {
    const payload = await readErrorPayload(response);
    throw new ApiError(response.status, extractBackendErrorMessage(payload));
  }

  return (await response.json()) as AuditResponse;
}
