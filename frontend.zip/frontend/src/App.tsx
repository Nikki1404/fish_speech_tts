import { useEffect, useMemo, useState, type CSSProperties } from 'react';
import { FloatingLines } from './components/FloatingLines/FloatingLines';
import { ErrorMessage } from './components/ErrorMessage/ErrorMessage';
import { FileUpload } from './components/FileUpload/FileUpload';
import { LoadingState } from './components/LoadingState/LoadingState';
import { Results } from './components/Results/Results';
import { uploadAuditCsv } from './services/api';
import { getFriendlyErrorMessage } from './utils/error';
import type { AnalysisSettingsFormState, AuditResponse } from './types/api';

const DEFAULT_SETTINGS: AnalysisSettingsFormState = {
  logisticCaliperMultiplier: '0.2',
  knnControlQuantile: '0.75',
  maxItems: '',
};

const THEME_STORAGE_KEY = 'ghost-denials-theme';
type ThemeMode = 'light' | 'dark';

function GridIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="20" height="20" aria-hidden="true">
      <rect x="3" y="3" width="7" height="7" rx="1.5"/>
      <rect x="14" y="3" width="7" height="7" rx="1.5"/>
      <rect x="3" y="14" width="7" height="7" rx="1.5"/>
      <rect x="14" y="14" width="7" height="7" rx="1.5"/>
    </svg>
  );
}

function CurveIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="20" height="20" aria-hidden="true">
      <polyline points="3,18 8,12 13,9 21,4"/>
      <circle cx="8" cy="12" r="2" fill="currentColor" stroke="none"/>
      <circle cx="13" cy="9" r="2" fill="currentColor" stroke="none"/>
    </svg>
  );
}

function NetworkIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="20" height="20" aria-hidden="true">
      <circle cx="12" cy="12" r="2.5" fill="currentColor" stroke="none"/>
      <circle cx="4" cy="6" r="2"/>
      <circle cx="20" cy="6" r="2"/>
      <circle cx="4" cy="18" r="2"/>
      <circle cx="20" cy="18" r="2"/>
      <line x1="6" y1="7" x2="10.5" y2="10.5"/>
      <line x1="18" y1="7" x2="13.5" y2="10.5"/>
      <line x1="6" y1="17" x2="10.5" y2="13.5"/>
      <line x1="18" y1="17" x2="13.5" y2="13.5"/>
    </svg>
  );
}

const ALGO_FEATURES = [
  { num: '01', label: 'Exact Match',         description: 'Equivalence-class matching on governed categorical bands', colorVar: '--accent', Icon: GridIcon    },
  { num: '02', label: 'Logistic Regression', description: 'Propensity-matched denial candidate detection',              colorVar: '--amber',  Icon: CurveIcon   },
  { num: '03', label: 'k-NN Retrieval',      description: 'Nearest-neighbor approved-twin identification',             colorVar: '--violet', Icon: NetworkIcon },
];

function SunIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="5"/>
      <line x1="12" y1="1"  x2="12" y2="3"/>
      <line x1="12" y1="21" x2="12" y2="23"/>
      <line x1="4.22"  y1="4.22"  x2="5.64"  y2="5.64"/>
      <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
      <line x1="1"  y1="12" x2="3"  y2="12"/>
      <line x1="21" y1="12" x2="23" y2="12"/>
      <line x1="4.22"  y1="19.78" x2="5.64"  y2="18.36"/>
      <line x1="18.36" y1="5.64"  x2="19.78" y2="4.22"/>
    </svg>
  );
}

function MoonIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
    </svg>
  );
}

function parsePositiveNumber(value: string): number | undefined {
  if (!value.trim()) {
    return undefined;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function validateCsvFile(file: File | null): string | null {
  if (!file) {
    return 'Please choose a CSV file before analyzing.';
  }

  const looksLikeCsv =
    file.name.toLowerCase().endsWith('.csv') ||
    file.type === 'text/csv' ||
    file.type === 'application/vnd.ms-excel';

  if (!looksLikeCsv) {
    return 'This file is not a valid CSV.';
  }

  if (file.size === 0) {
    return 'The selected file is empty.';
  }

  return null;
}

export default function App() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [settings, setSettings] = useState<AnalysisSettingsFormState>(DEFAULT_SETTINGS);
  const [result, setResult] = useState<AuditResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [themeMode, setThemeMode] = useState<ThemeMode>('light');
  const [pointerPosition, setPointerPosition] = useState({ x: 50, y: 20 });

  useEffect(() => {
    const storedTheme = window.localStorage.getItem(THEME_STORAGE_KEY);
    const preferredTheme: ThemeMode =
      storedTheme === 'dark' || storedTheme === 'light'
        ? storedTheme
        : window.matchMedia('(prefers-color-scheme: dark)').matches
          ? 'dark'
          : 'light';

    setThemeMode(preferredTheme);
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = themeMode;
    window.localStorage.setItem(THEME_STORAGE_KEY, themeMode);
  }, [themeMode]);

  const themeLabel = useMemo(
    () => (themeMode === 'light' ? 'Switch to dark theme' : 'Switch to light theme'),
    [themeMode],
  );

  const backgroundStyle = {
    '--pointer-x': `${pointerPosition.x}%`,
    '--pointer-y': `${pointerPosition.y}%`,
  } as CSSProperties;

  const resetAll = () => {
    setSelectedFile(null);
    setResult(null);
    setError(null);
    setSettings(DEFAULT_SETTINGS);
  };

  const handleAnalyze = async () => {
    const validationError = validateCsvFile(selectedFile);
    if (validationError) {
      setError(validationError);
      return;
    }

    const logisticCaliperMultiplier = Number(settings.logisticCaliperMultiplier);
    const knnControlQuantile = Number(settings.knnControlQuantile);
    const maxItems = parsePositiveNumber(settings.maxItems);

    if (!Number.isFinite(logisticCaliperMultiplier) || !Number.isFinite(knnControlQuantile)) {
      setError('Please enter valid numeric analysis settings.');
      return;
    }

    setError(null);
    setIsSubmitting(true);

    try {
      const response = await uploadAuditCsv(selectedFile as File, {
        logisticCaliperMultiplier,
        knnControlQuantile,
        maxItems,
      });
      setResult(response);
    } catch (caughtError) {
      setResult(null);
      setError(getFriendlyErrorMessage(caughtError));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="page-root"
      onPointerMove={(event) => {
        setPointerPosition({
          x: (event.clientX / window.innerWidth)  * 100,
          y: (event.clientY / window.innerHeight) * 100,
        });
      }}
    >
      <div className="background-layer" style={backgroundStyle}>
        <div className="background-orb background-orb-left" />
        <div className="background-orb background-orb-right" />
        <div className="background-orb background-orb-mid" />
        <div className="background-grid" />
        <div className="background-spotlight" />
      </div>
      <FloatingLines />

      <header className="site-header">
        <div className="header-inner">
          <div className="brand">
            <div className="brand-monogram" aria-hidden="true">GD</div>
            <div className="brand-text">
              <span className="brand-name">Ghost Denials</span>
              <span className="brand-tagline">Claims Audit Platform</span>
            </div>
          </div>

          <div className="header-actions">
            <span className="status-chip">
              <span className="status-dot" aria-hidden="true" />
              FastAPI
            </span>
            <button
              type="button"
              className="theme-button"
              aria-label={themeLabel}
              onClick={() => setThemeMode(themeMode === 'light' ? 'dark' : 'light')}
            >
              {themeMode === 'light' ? <MoonIcon /> : <SunIcon />}
            </button>
          </div>
        </div>
      </header>

      <main className="main-content">
        <div className="process-strip">
          {ALGO_FEATURES.flatMap((feature, index) => {
            const card = (
              <div
                key={feature.num}
                className="process-card"
                style={{ '--card-color': `var(${feature.colorVar})` } as CSSProperties}
              >
                <div className="process-card-top">
                  <span className="process-badge">{feature.num}</span>
                  <span className="process-icon"><feature.Icon /></span>
                </div>
                <strong className="process-label">{feature.label}</strong>
                <p className="process-desc">{feature.description}</p>
              </div>
            );
            const connector = index < ALGO_FEATURES.length - 1
              ? (
                <div key={`c${index}`} className="process-connector" aria-hidden="true">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" width="16" height="16">
                    <polyline points="9,18 15,12 9,6"/>
                  </svg>
                </div>
              ) : null;
            return connector ? [card, connector] : [card];
          })}
        </div>

        <div className="content-stack">
          <FileUpload
            selectedFile={selectedFile}
            isSubmitting={isSubmitting}
            settings={settings}
            onSelectFile={(file) => {
              setSelectedFile(file);
              setError(null);
              setResult(null);
            }}
            onSettingsChange={(nextSettings) => setSettings(nextSettings)}
            onAnalyze={handleAnalyze}
            onClearResults={() => setError(null)}
          />

          <div className="status-stack">
            {error ? <ErrorMessage message={error} /> : null}
            {isSubmitting ? <LoadingState /> : null}
            {result ? <Results result={result} onReset={resetAll} /> : null}
          </div>
        </div>
      </main>

      <footer className="site-footer">
        <div className="footer-inner">
          <div className="footer-brand">
            <span className="brand-name">Ghost Denials</span>
            <p className="footer-copy">React + Vite · FastAPI · Machine Learning</p>
          </div>
          <div className="footer-badges">
            <span className="footer-badge">Exact Match</span>
            <span className="footer-badge">Logistic Regression</span>
            <span className="footer-badge">k-NN</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
