export function getFriendlyErrorMessage(error: unknown): string {
  if (error instanceof Error && error.message) {
    return error.message;
  }

  return 'Something went wrong while processing the CSV.';
}

export function extractBackendErrorMessage(payload: unknown): string {
  if (typeof payload === 'string' && payload.trim()) {
    return payload.trim();
  }

  if (!payload || typeof payload !== 'object') {
    return 'The analysis service returned an unexpected error.';
  }

  const detail = (payload as { detail?: unknown }).detail;
  if (typeof detail === 'string') {
    return detail;
  }

  if (Array.isArray(detail)) {
    const messages = detail
      .map((entry) => {
        if (!entry || typeof entry !== 'object') {
          return '';
        }

        const item = entry as { loc?: unknown; msg?: unknown };
        const location = Array.isArray(item.loc)
          ? item.loc.map((segment) => String(segment)).join('.')
          : '';
        const message = typeof item.msg === 'string' ? item.msg : '';
        return location ? `${location}: ${message}` : message;
      })
      .filter(Boolean);

    if (messages.length > 0) {
      return messages.join(' ');
    }
  }

  return 'The analysis service returned an unexpected error.';
}
