type LoadingStateProps = {
  title?: string;
  subtitle?: string;
};

export function LoadingState({
  title = 'Analyzing CSV...',
  subtitle = 'Please wait while FastAPI processes the uploaded file.',
}: LoadingStateProps) {
  return (
    <div className="loading-state" role="status" aria-live="polite">
      <span className="spinner" aria-hidden="true" />
      <div>
        <h2>{title}</h2>
        <p>{subtitle}</p>
      </div>
    </div>
  );
}
