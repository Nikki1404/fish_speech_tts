type ErrorMessageProps = {
  message: string;
};

export function ErrorMessage({ message }: ErrorMessageProps) {
  return (
    <div className="error-banner" role="alert">
      <div>
        <h2>Upload failed</h2>
        <p>{message}</p>
      </div>
    </div>
  );
}
