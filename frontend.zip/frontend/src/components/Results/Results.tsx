import type { AuditResponse, SchemaReport } from '../../types/api';

type ResultsProps = {
  result: AuditResponse;
  onReset: () => void;
};

/** Label the ID column with the name used in the uploaded file, not ours. */
function identifierLabel(report: SchemaReport | undefined): string {
  return report?.id_column?.source || 'VisitID#';
}

function SchemaNotice({ report }: { report: SchemaReport }) {
  if (report.mode === 'strict') {
    return null;
  }

  const { status_mapping: status, row_counts: counts } = report;
  const isBlocked = report.mode === 'insufficient';

  return (
    <div className={`schema-notice ${isBlocked ? 'schema-notice-blocked' : ''}`}>
      <div className="schema-notice-head">
        <span className="schema-badge">
          {isBlocked ? 'Could not analyze' : 'Schema adapted'}
        </span>
        <p>
          {isBlocked
            ? report.reason
            : 'This file did not use the standard column names, so they were mapped automatically.'}
        </p>
      </div>

      <dl className="schema-facts">
        <div>
          <dt>Identifier column</dt>
          <dd>{report.id_column.source ?? 'not found'}</dd>
        </div>
        {status?.status_column ? (
          <div>
            <dt>Status column</dt>
            <dd>{status.status_column}</dd>
          </div>
        ) : null}
        {status?.approved_values?.length ? (
          <div>
            <dt>Read as approved</dt>
            <dd>{status.approved_values.join(', ')}</dd>
          </div>
        ) : null}
        {status?.denied_values?.length ? (
          <div>
            <dt>Read as denied</dt>
            <dd>{status.denied_values.join(', ')}</dd>
          </div>
        ) : null}
        {typeof counts?.denied_candidates === 'number' ? (
          <div>
            <dt>Denied claims audited</dt>
            <dd>
              {counts.denied_candidates}
              {typeof counts.administrative_excluded === 'number' &&
              counts.administrative_excluded > 0
                ? ` (${counts.administrative_excluded} administrative excluded)`
                : ''}
            </dd>
          </div>
        ) : null}
      </dl>

      {report.warnings.length > 0 ? (
        <ul className="schema-warnings">
          {report.warnings.map((warning) => (
            <li key={warning}>{warning}</li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

const ALGORITHMS = [
  {
    key: 'exact_match' as const,
    label: 'Exact match',
    description: 'Equivalence-class matches from the governed categorical bands.',
  },
  {
    key: 'logistic_regression' as const,
    label: 'Logistic regression',
    description: 'Propensity-matched denied claim identifiers.',
  },
  {
    key: 'k-NN' as const,
    label: 'k-NN',
    description: 'Nearest-neighbor approved-twin retrieval results.',
  },
] as const;

export function Results({ result, onReset }: ResultsProps) {
  const totalCandidates =
    result.exact_match.length +
    result.logistic_regression.length +
    result['k-NN'].length;

  const report = result.schema_report;
  const idLabel = identifierLabel(report);
  const blocked = report?.mode === 'insufficient';

  return (
    <section className="panel results-panel">
      <div className="panel-header results-header">
        <div>
          <p className="eyebrow">Results</p>
          <h2>{blocked ? 'Analysis not possible' : 'Analysis complete'}</h2>
          <p className="muted-copy">
            {blocked
              ? 'This CSV could not be analyzed. See the details below.'
              : 'FastAPI returned the three candidate lists for the uploaded CSV.'}
          </p>
        </div>
        <button type="button" className="ghost-button" onClick={onReset}>
          Upload another CSV
        </button>
      </div>

      {report ? <SchemaNotice report={report} /> : null}

      <div className="metrics-grid">
        <article className="metric-card">
          <span className="metric-label">Exact match</span>
          <strong>{result.exact_match.length}</strong>
        </article>
        <article className="metric-card">
          <span className="metric-label">Logistic regression</span>
          <strong>{result.logistic_regression.length}</strong>
        </article>
        <article className="metric-card">
          <span className="metric-label">k-NN</span>
          <strong>{result['k-NN'].length}</strong>
        </article>
        <article className="metric-card accent-card">
          <span className="metric-label">Total candidates</span>
          <strong>{totalCandidates}</strong>
        </article>
      </div>

      <div className="results-list">
        {ALGORITHMS.map((algorithm) => {
          const values = result[algorithm.key];

          return (
            <article className="result-block" key={algorithm.key}>
              <div className="result-block-header">
                <div>
                  <h3>{algorithm.label}</h3>
                  <p>{algorithm.description}</p>
                </div>
                <span className="count-pill">{values.length} IDs</span>
              </div>

              {values.length > 0 ? (
                <div className="table-shell">
                  <table>
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Denied {idLabel}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {values.map((value, index) => (
                        <tr key={value}>
                          <td>{index + 1}</td>
                          <td>{value}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="empty-state">No matches were returned for this algorithm.</p>
              )}
            </article>
          );
        })}
      </div>
    </section>
  );
}
