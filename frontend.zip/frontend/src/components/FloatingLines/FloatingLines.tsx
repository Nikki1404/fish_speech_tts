import { useEffect, useRef } from 'react';

type Particle = { x: number; y: number; vx: number; vy: number };

const COUNT     = 72;
const LINK_DIST = 140;   // particle-to-particle connection range (px)
const PULL_DIST = 220;   // cursor attraction range (px)
const PULL_STR  = 0.032;
const DAMPING   = 0.93;
const MAX_SPEED = 1.6;
const DRIFT     = 0.055;

function make(w: number, h: number): Particle[] {
  return Array.from({ length: COUNT }, () => ({
    x:  Math.random() * w,
    y:  Math.random() * h,
    vx: (Math.random() - 0.5) * 1.2,
    vy: (Math.random() - 0.5) * 1.2,
  }));
}

export function FloatingLines() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mxRef     = useRef(-9999);
  const myRef     = useRef(-9999);
  const ptsRef    = useRef<Particle[]>([]);
  const rafRef    = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
      ptsRef.current = make(canvas.width, canvas.height);
    };

    const onMove  = (e: MouseEvent) => { mxRef.current = e.clientX; myRef.current = e.clientY; };
    const onLeave = ()               => { mxRef.current = -9999;     myRef.current = -9999; };

    const tick = () => {
      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const dark = document.documentElement.dataset.theme === 'dark';
      const rgb  = dark ? '45,212,191' : '13,148,136';
      const cX = mxRef.current;
      const cY = myRef.current;

      for (const p of ptsRef.current) {
        p.vx += (Math.random() - 0.5) * DRIFT;
        p.vy += (Math.random() - 0.5) * DRIFT;

        const dx = cX - p.x;
        const dy = cY - p.y;
        const d  = Math.hypot(dx, dy);
        if (d < PULL_DIST && d > 1) {
          const f = (1 - d / PULL_DIST) * PULL_STR;
          p.vx += (dx / d) * f;
          p.vy += (dy / d) * f;
        }

        p.vx *= DAMPING;
        p.vy *= DAMPING;
        const spd = Math.hypot(p.vx, p.vy);
        if (spd > MAX_SPEED) { p.vx = (p.vx / spd) * MAX_SPEED; p.vy = (p.vy / spd) * MAX_SPEED; }

        p.x += p.vx; if (p.x < 0) p.x = W; else if (p.x > W) p.x = 0;
        p.y += p.vy; if (p.y < 0) p.y = H; else if (p.y > H) p.y = 0;
      }

      // Particle-to-particle lines
      ctx.lineWidth = 1;
      for (let i = 0; i < ptsRef.current.length; i++) {
        const a = ptsRef.current[i];
        for (let j = i + 1; j < ptsRef.current.length; j++) {
          const b = ptsRef.current[j];
          const dist = Math.hypot(a.x - b.x, a.y - b.y);
          if (dist < LINK_DIST) {
            ctx.strokeStyle = `rgba(${rgb},${(1 - dist / LINK_DIST) * 0.26})`;
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
      }

      // Cursor-to-particle attraction lines
      if (cX > -9000) {
        ctx.lineWidth = 1.5;
        for (const p of ptsRef.current) {
          const dist = Math.hypot(cX - p.x, cY - p.y);
          if (dist < PULL_DIST) {
            ctx.strokeStyle = `rgba(${rgb},${(1 - dist / PULL_DIST) * 0.42})`;
            ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(cX, cY); ctx.stroke();
          }
        }
        ctx.fillStyle = `rgba(${rgb},0.55)`;
        ctx.beginPath(); ctx.arc(cX, cY, 3, 0, Math.PI * 2); ctx.fill();
      }

      // Particle dots
      ctx.fillStyle = `rgba(${rgb},0.36)`;
      for (const p of ptsRef.current) {
        ctx.beginPath(); ctx.arc(p.x, p.y, 2, 0, Math.PI * 2); ctx.fill();
      }

      rafRef.current = requestAnimationFrame(tick);
    };

    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseleave', onLeave);
    rafRef.current = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseleave', onLeave);
    };
  }, []);

  return <canvas ref={canvasRef} className="lines-canvas" aria-hidden="true" />;
}
