import { useMemo, useRef, useState } from 'react';
import { formatFileSize } from '../../utils/file';
import type { AnalysisSettingsFormState } from '../../types/api';

type FileUploadProps = {
  selectedFile: File | null;
  isSubmitting: boolean;
  settings: AnalysisSettingsFormState;
  onSelectFile: (file: File | null) => void;
  onSettingsChange: (nextSettings: AnalysisSettingsFormState) => void;
  onAnalyze: () => void;
  onClearResults: () => void;
};

const ACCEPTED_TYPES = ['text/csv', 'application/vnd.ms-excel'];

export function FileUpload({
  selectedFile,
  isSubmitting,
  settings,
  onSelectFile,
  onSettingsChange,
  onAnalyze,
  onClearResults,
}: FileUploadProps) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const fileInfo = useMemo(() => {
    if (!selectedFile) {
      return null;
    }

    return {
      size: formatFileSize(selectedFile.size),
      type: selectedFile.type || 'CSV',
      modified: selectedFile.lastModified
        ? new Date(selectedFile.lastModified).toLocaleString()
        : null,
    };
  }, [selectedFile]);

  const pickFile = () => {
    inputRef.current?.click();
  };

  const handleFile = (file: File | null) => {
    onClearResults();
    onSelectFile(file);
  };

  const validateAndSelect = (file: File | null) => {
    if (!file) {
      handleFile(null);
      return;
    }

    const looksLikeCsv =
      file.name.toLowerCase().endsWith('.csv') ||
      ACCEPTED_TYPES.includes(file.type);

    if (!looksLikeCsv) {
      handleFile(null);
      return;
    }

    handleFile(file);
  };

  return (
    <section className="panel upload-panel">
      <div className="panel-header">
        <div>
          <p className="eyebrow">Upload</p>
          <h2>CSV Analyzer</h2>
        </div>
      </div>

      <div
        className={`dropzone ${isDragging ? 'dropzone-dragging' : ''}`}
        onClick={pickFile}
        onDragEnter={(event) => {
          event.preventDefault();
          setIsDragging(true);
        }}
        onDragOver={(event) => {
          event.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={(event) => {
          event.preventDefault();
          setIsDragging(false);
        }}
        onDrop={(event) => {
          event.preventDefault();
          setIsDragging(false);
          validateAndSelect(event.dataTransfer.files.item(0));
        }}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".csv,text/csv"
          className="sr-only"
          onChange={(event) => validateAndSelect(event.target.files?.item(0) ?? null)}
        />
        <div className="dropzone-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="28" height="28">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="17 8 12 3 7 8"/>
            <line x1="12" y1="3" x2="12" y2="15"/>
          </svg>
        </div>
        <div className="dropzone-copy">
          <p className="dropzone-title">Drop your CSV here</p>
          <p className="dropzone-subtitle">or click to browse from your device</p>
        </div>
      </div>

      <div className="file-summary">
        <div>
          <p className="field-label">Selected file</p>
          <p className="file-name">{selectedFile ? selectedFile.name : 'No file selected yet'}</p>
        </div>

        {selectedFile ? (
          <button
            type="button"
            className="text-button"
            onClick={() => {
              onClearResults();
              onSelectFile(null);
              if (inputRef.current) {
                inputRef.current.value = '';
              }
            }}
            disabled={isSubmitting}
          >
            Remove
          </button>
        ) : null}
      </div>

      {fileInfo ? (
        <dl className="file-meta">
          <div>
            <dt>Size</dt>
            <dd>{fileInfo.size}</dd>
          </div>
          <div>
            <dt>Type</dt>
            <dd>{fileInfo.type}</dd>
          </div>
          {fileInfo.modified ? (
            <div>
              <dt>Modified</dt>
              <dd>{fileInfo.modified}</dd>
            </div>
          ) : null}
        </dl>
      ) : null}

      <div className="settings-divider">
        <span className="settings-section-label">Algorithm settings</span>
      <div className="settings-grid">
        <label>
          <span>Logistic caliper multiplier</span>
          <input
            type="number"
            min="0.01"
            max="2"
            step="0.01"
            value={settings.logisticCaliperMultiplier}
            onChange={(event) =>
              onSettingsChange({
                ...settings,
                logisticCaliperMultiplier: event.target.value,
              })
            }
          />
        </label>

        <label>
          <span>k-NN control quantile</span>
          <input
            type="number"
            min="0.01"
            max="0.99"
            step="0.01"
            value={settings.knnControlQuantile}
            onChange={(event) =>
              onSettingsChange({
                ...settings,
                knnControlQuantile: event.target.value,
              })
            }
          />
        </label>

        <label>
          <span>Max items</span>
          <input
            type="number"
            min="1"
            step="1"
            placeholder="All"
            value={settings.maxItems}
            onChange={(event) =>
              onSettingsChange({
                ...settings,
                maxItems: event.target.value,
              })
            }
          />
        </label>
      </div>
      </div>

      <div className="panel-actions">
        <button
          type="button"
          className="primary-button"
          disabled={!selectedFile || isSubmitting}
          onClick={onAnalyze}
        >
          {isSubmitting ? 'Analyzing CSV...' : 'Analyze CSV'}
        </button>
      </div>
    </section>
  );
}
