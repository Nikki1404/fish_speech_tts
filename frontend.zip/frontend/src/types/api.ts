export interface ColumnMapping {
  source: string | null;
  confidence: 'high' | 'medium' | 'low' | 'override' | 'missing';
}

export interface StatusMapping {
  status_column?: string | null;
  status_code_column?: string | null;
  approved_values?: string[];
  denied_values?: string[];
  unclassified_values?: string[];
}

/**
 * How the backend interpreted the uploaded CSV.
 *
 * `strict`       the file already matched the canonical schema
 * `adapted`      column names / status wording were mapped automatically
 * `insufficient` the file lacks an identifier or one of the two classes
 */
export interface SchemaReport {
  mode: 'strict' | 'adapted' | 'insufficient';
  reason?: string;
  id_column: ColumnMapping & { canonical: string };
  column_mapping: Record<string, ColumnMapping>;
  status_mapping: StatusMapping;
  row_counts: Record<string, number>;
  unmapped_columns: string[];
  warnings: string[];
  id_sample?: string[];
}

export interface AuditResponse {
  exact_match: string[];
  logistic_regression: string[];
  'k-NN': string[];
  /** Optional and additive: older backends simply omit it. */
  schema_report?: SchemaReport;
}

export interface UploadAuditCsvOptions {
  logisticCaliperMultiplier: number;
  knnControlQuantile: number;
  maxItems?: number;
}

export interface AnalysisSettingsFormState {
  logisticCaliperMultiplier: string;
  knnControlQuantile: string;
  maxItems: string;
}
