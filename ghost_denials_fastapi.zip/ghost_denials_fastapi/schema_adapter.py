#!/usr/bin/env python3
"""Schema adaptation layer for arbitrary AR / claims CSV exports.

The three candidate generators (exact_match, logistic_regression, knn) require a
fixed schema and a fixed status vocabulary:

    columns : VisitID#, DOS, Submitted Date, Insurance Name, Status, Status Code,
              Action Code, Primary/Secondary, Client, Billed Amount, Aging Days
    approved: Status == "Claim at insurance" AND Status Code == "Claim in Process"
    denied  : Status == "Denied" minus administrative status codes

Real-world exports rarely use those exact names or those exact words. This module
sits *in front* of the algorithms: it inspects an uploaded CSV, works out which
column carries the unique identifier, which carries the claim status, and which
carries the reason/sub-status, then rewrites the file into the canonical schema
above. The algorithm modules are never modified and never learn that the source
file looked different.

Three outcomes are possible:

    strict       every canonical column and both canonical classes are present;
                 the original file is used untouched (bit-for-bit old behaviour)
    adapted      a mapping was inferred (or supplied); a canonical CSV is built
    insufficient no usable identifier or only one class exists; the caller should
                 return empty lists plus the reason rather than raising

Identifiers are round-tripped through opaque surrogate keys so that pandas cannot
mangle them on the way back in (leading zeros, ``.0`` suffixes on numeric columns
containing blanks, and Excel scientific notation are all silently destructive).
The caller restores the original identifier text via ``restore_ids``.
"""

from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from pathlib import Path

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------- #
# Canonical target schema
# --------------------------------------------------------------------------- #

ID_COLUMN = "VisitID#"

CANONICAL_COLUMNS = [
    "VisitID#", "DOS", "Submitted Date", "Insurance Name", "Status",
    "Status Code", "Action Code", "Primary/Secondary", "Client",
    "Billed Amount", "Aging Days",
]

# Literals the downstream algorithms compare against.
APPROVED_STATUS = "Claim at insurance"
APPROVED_STATUS_CODE = "Claim in Process"
DENIED_STATUS = "Denied"
OTHER_STATUS = "Other"
DEFAULT_DENIED_CODE = "Denied by payer"
ADMIN_CANONICAL_CODE = "Incorrect Submission"

UNKNOWN_CATEGORY = "UNKNOWN"
FALLBACK_DATE = pd.Timestamp("2024-01-01")

# Fields matched before the greedy/fuzzy pass; order matters so that the more
# specific name claims its column before a shorter name can steal it.
MATCH_ORDER = [
    "Status Code", "Submitted Date", "Billed Amount", "Aging Days", "VisitID#",
    "DOS", "Insurance Name", "Primary/Secondary", "Client", "Action Code",
    "Status",
]

COLUMN_ALIASES: dict[str, tuple[str, ...]] = {
    "VisitID#": (
        "visitid#", "visitid", "visit id", "visit number", "visit no",
        "claim id", "claimid", "claim number", "claim no", "claim #",
        "claim key", "encounter id", "encounter number", "account number",
        "account no", "acct no", "patient account", "patient account number",
        "invoice number", "invoice no", "invoice", "item id", "record id",
        "reference number", "reference no", "control number", "icn", "dcn",
        "tracking number", "id",
    ),
    "Status": (
        "status", "claim status", "current status", "claim state", "state",
        "payment status", "disposition", "outcome", "adjudication status",
        "pre call status", "claim outcome", "result",
    ),
    "Status Code": (
        "status code", "statuscode", "sub status", "substatus", "reason code",
        "reason", "denial reason", "denial code", "denial description",
        "adjustment reason", "carc", "carc code", "rarc", "remark code",
        "remark", "post call status code", "category", "sub category",
        "resolution code",
    ),
    "Action Code": (
        "action code", "action", "next action", "next step", "recommended action",
        "follow up action", "resolution", "action taken", "disposition code",
    ),
    "Billed Amount": (
        "billed amount", "billed amt", "billed", "charge amount", "charges",
        "total charges", "total charge", "claim amount", "amount billed",
        "gross charges", "billed charges", "line charge", "amount",
    ),
    "Aging Days": (
        "aging days", "aging", "age", "age days", "days outstanding",
        "days in ar", "ar days", "days aged", "outstanding days", "day count",
        "days since submission",
    ),
    "DOS": (
        "dos", "date of service", "service date", "svc date", "dos from",
        "from date of service", "service from", "start of service",
        "treatment date", "encounter date",
    ),
    "Submitted Date": (
        "submitted date", "submission date", "date submitted", "submit date",
        "billed date", "date billed", "claim date", "filed date", "date filed",
        "sent date", "transmission date", "first billed date",
    ),
    "Insurance Name": (
        "insurance name", "insurance", "insurance company", "payer", "payor",
        "payer name", "payor name", "carrier", "carrier name", "plan name",
        "plan", "insurance carrier",
    ),
    "Primary/Secondary": (
        "primary/secondary", "primary secondary", "coverage level", "cob",
        "payer sequence", "payer rank", "insurance type", "insurance level",
        "coverage order", "payer level", "filing order", "insurance sequence",
    ),
    "Client": (
        "client", "client name", "facility", "facility name", "practice",
        "practice name", "provider group", "group", "location", "site",
        "entity", "department", "region", "organization",
    ),
}

# --------------------------------------------------------------------------- #
# Status vocabulary
# --------------------------------------------------------------------------- #

# Checked BEFORE the approved patterns: "not paid" contains "paid".
DENIED_PATTERNS = (
    r"\bdenied\b", r"\bdenial[s]?\b", r"\bdeny\b", r"\bdenies\b",
    r"\breject(?:ed|ion|s)?\b",
    r"\bnot\s*paid\b", r"\bnon[\s-]*payment\b", r"\bunpaid\b", r"\bno\s*pay\b",
    r"\bzero\s*pay(?:ment)?\b", r"\bnil\s*pay(?:ment)?\b",
    r"\brefused\b", r"\bdisallowed\b", r"\bnot\s*covered\b",
    r"\bnon[\s-]*covered\b", r"\bwrite[\s-]*off\b", r"\bwriteoff\b",
    r"\bunderpaid\b", r"\bshort\s*paid\b",
)

APPROVED_PATTERNS = (
    r"\bpaid\b", r"\bapproved\b", r"\bapproval\b", r"\ballowed\b",
    r"\badjudicated\b", r"\bsettled\b", r"\baccepted\b", r"\bcleared\b",
    r"\bclaim\s*in\s*process\b", r"\bin\s*process(?:ing)?\b", r"\bprocessed\b",
    r"\bclaim(?:ed)?\s*at\s*insurance\b", r"\bat\s*insurance\b",
    r"\bwith\s*payer\b", r"\bwith\s*insurance\b", r"\breceived\s*by\s*payer\b",
    r"\backnowledged\b", r"\bclean\s*claim\b", r"\bunder\s*review\b",
    r"\bin\s*review\b", r"\bclaimed\b", r"\bin\s*adjudication\b",
    r"\bpending\s*(?:with|at)\s*(?:payer|insurance)\b", r"\breimbursed\b",
)

# Administrative / incomplete-submission reasons. These are denials but they are
# excluded from the candidate pool, mirroring ADMIN_EXCLUSION_STATUS_CODES.
#
# Deliberately narrow: it covers "the claim was never properly submitted", not
# "the payer considered it and said no". Coverage/eligibility/medical-necessity
# denials are substantive decisions and stay in the candidate pool. Callers who
# disagree can widen this per request via status_map.admin_excluded.
ADMIN_PATTERNS = (
    r"\bincorrect\s*submission\b", r"\bprovider\s*info(?:rmation)?\s*missing\b",
    r"\bclaim\s*not\s*on\s*file\b", r"\bnot\s*on\s*file\b", r"\bno\s*record\b",
    r"\bnever\s*received\b",
    r"\bmissing\s*info(?:rmation)?\b", r"\bmissing\s*document",
    r"\bincomplete\s*(?:claim|submission|information)?\b",
    r"\bneeds?\s*correction\b", r"\bcorrected\s*claim\s*required\b",
    r"\bresubmit\b", r"\bresubmission\b",
    r"\bregistration\s*error\b", r"\bdemographic\s*error\b",
)

_DENIED_RE = re.compile("|".join(DENIED_PATTERNS), re.IGNORECASE)
_APPROVED_RE = re.compile("|".join(APPROVED_PATTERNS), re.IGNORECASE)
_ADMIN_RE = re.compile("|".join(ADMIN_PATTERNS), re.IGNORECASE)

APPROVED = "approved"
DENIED = "denied"
UNKNOWN = "unknown"


def classify_status_value(value: str) -> str:
    """Bucket a single raw status string into approved / denied / unknown."""

    text = str(value or "").strip()
    if not text:
        return UNKNOWN
    # Denied is tested first: "not paid" and "non-covered" both contain tokens
    # that would otherwise trip the approved patterns.
    if _DENIED_RE.search(text):
        return DENIED
    if _APPROVED_RE.search(text):
        return APPROVED
    return UNKNOWN


def is_admin_value(value: str) -> bool:
    text = str(value or "").strip()
    return bool(text) and bool(_ADMIN_RE.search(text))


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #

_NON_ALNUM = re.compile(r"[^a-z0-9]+")


def _norm(name: str) -> str:
    """Fold a header down to comparable letters and digits."""

    return _NON_ALNUM.sub(" ", str(name).strip().lower()).strip()


def _squash(name: str) -> str:
    return _norm(name).replace(" ", "")


_NORMALIZED_ALIASES = {
    canonical: {_squash(alias) for alias in aliases}
    for canonical, aliases in COLUMN_ALIASES.items()
}

_MONEY_STRIP = re.compile(r"[^0-9.\-]")


def to_number(series: pd.Series) -> pd.Series:
    """Coerce '$1,234.50', '(123.45)' and '1 234,00' style values to floats."""

    text = series.astype(str).str.strip()
    negative = text.str.match(r"^\(.*\)$", na=False) | text.str.startswith("-")
    cleaned = text.str.replace(_MONEY_STRIP, "", regex=True)
    cleaned = cleaned.str.replace(r"(?<=.)-", "", regex=True)
    numbers = pd.to_numeric(cleaned, errors="coerce").abs()
    return numbers.where(~negative, -numbers)


_SLASHED_DATE = re.compile(r"^\s*(\d{1,2})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*\d{2,4}")


def _clean_dates(series: pd.Series) -> pd.Series:
    text = series.astype(str).str.strip()
    return text.where(~text.str.lower().isin(["", "nan", "nat", "none", "null"]))


def infer_dayfirst(columns: list[pd.Series]) -> bool:
    """Decide dd/mm vs mm/dd once, using evidence from every date column.

    A value whose first component exceeds 12 can only be a day; one whose second
    component exceeds 12 can only be a month. Deciding per-column (or per-value,
    as ``format="mixed"`` does) lets one file parse two ways and silently
    produces negative filing delays.
    """

    day_evidence = month_evidence = 0
    for series in columns:
        for value in _clean_dates(series).dropna().head(400):
            match = _SLASHED_DATE.match(str(value))
            if not match:
                continue
            first, second = int(match.group(1)), int(match.group(2))
            if first > 12 >= second:
                day_evidence += 1
            elif second > 12 >= first:
                month_evidence += 1
    return day_evidence > month_evidence


def to_datetime(series: pd.Series, dayfirst: bool = False) -> pd.Series:
    """Parse a date column using a single, file-wide day/month convention."""

    text = _clean_dates(series)
    try:
        return pd.to_datetime(
            text, errors="coerce", format="mixed", dayfirst=dayfirst
        )
    except (ValueError, TypeError):
        return pd.to_datetime(text, errors="coerce", dayfirst=dayfirst)


def _looks_like_dates(series: pd.Series) -> bool:
    sample = series[series.astype(str).str.strip() != ""].head(200)
    if sample.empty:
        return False
    return to_datetime(sample).notna().mean() > 0.8


# --------------------------------------------------------------------------- #
# Robust CSV loading
# --------------------------------------------------------------------------- #

def _decode(path: str | Path) -> str:
    raw = Path(path).read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", errors="replace")


def _sniff_delimiter(sample: str) -> str:
    try:
        return csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
    except csv.Error:
        counts = {d: sample.count(d) for d in (",", ";", "\t", "|")}
        best = max(counts, key=counts.get)
        return best if counts[best] else ","


def _find_header_row(text: str, delimiter: str) -> int:
    """Skip spreadsheet preamble ('Report run on ...') above the real header."""

    rows = list(csv.reader(io.StringIO(text), delimiter=delimiter))[:25]
    if not rows:
        return 0

    widths = [len(row) for row in rows if any(cell.strip() for cell in row)]
    if not widths:
        return 0
    modal_width = max(set(widths), key=widths.count)

    for index, row in enumerate(rows):
        cells = [cell.strip() for cell in row]
        filled = [cell for cell in cells if cell]
        if len(row) != modal_width or len(filled) < 2:
            continue
        # A header row has distinct, non-numeric labels.
        if len(set(filled)) != len(filled):
            continue
        if all(re.fullmatch(r"-?[\d.,]+", cell) for cell in filled):
            continue
        return index
    return 0


def load_table(path: str | Path) -> pd.DataFrame:
    """Read any CSV as pure text so no value is coerced or reformatted."""

    text = _decode(path)
    if not text.strip():
        raise ValueError("The uploaded CSV is empty.")

    delimiter = _sniff_delimiter(text[:8192])
    skip = _find_header_row(text, delimiter)

    frame = pd.read_csv(
        io.StringIO(text),
        sep=delimiter,
        dtype=str,
        keep_default_na=False,
        skiprows=skip,
        engine="python",
        on_bad_lines="skip",
    )
    frame.columns = [str(column).strip() for column in frame.columns]
    frame = frame.loc[:, [c for c in frame.columns if c and not c.startswith("Unnamed:")]]
    frame = frame.dropna(how="all")
    if frame.empty:
        raise ValueError("The uploaded CSV contains no data rows.")
    return frame.reset_index(drop=True)


# --------------------------------------------------------------------------- #
# Column detection
# --------------------------------------------------------------------------- #

@dataclass
class ColumnChoice:
    canonical: str
    source: str | None = None
    confidence: str = "missing"


def _fuzzy_score(column: str, canonical: str) -> float:
    squashed = _squash(column)
    best = 0.0
    for alias in _NORMALIZED_ALIASES[canonical]:
        if not alias:
            continue
        ratio = SequenceMatcher(None, squashed, alias).ratio()
        # Reward containment for names like "Primary Claim Status".
        if alias in squashed or squashed in alias:
            ratio = max(ratio, 0.9 if len(alias) >= 4 else ratio)
        best = max(best, ratio)
    return best


def detect_columns(frame: pd.DataFrame) -> dict[str, ColumnChoice]:
    """Map canonical field names onto the uploaded file's actual headers."""

    choices = {name: ColumnChoice(name) for name in CANONICAL_COLUMNS}
    available = list(frame.columns)
    claimed: set[str] = set()

    # Pass 1 - exact alias match on the normalised header.
    for canonical in MATCH_ORDER:
        aliases = _NORMALIZED_ALIASES[canonical]
        for column in available:
            if column in claimed:
                continue
            if _squash(column) in aliases:
                choices[canonical] = ColumnChoice(canonical, column, "high")
                claimed.add(column)
                break

    # Pass 2 - fuzzy match for whatever is still unresolved.
    for canonical in MATCH_ORDER:
        if choices[canonical].source is not None:
            continue
        best_column, best_score = None, 0.0
        for column in available:
            if column in claimed:
                continue
            score = _fuzzy_score(column, canonical)
            if score > best_score:
                best_column, best_score = column, score
        if best_column is not None and best_score >= 0.84:
            confidence = "medium" if best_score >= 0.9 else "low"
            choices[canonical] = ColumnChoice(canonical, best_column, confidence)
            claimed.add(best_column)

    return choices


def detect_id_column(
    frame: pd.DataFrame,
    hinted: str | None,
    exclude: set[str],
) -> tuple[str | None, str]:
    """Pick the unique-identifier column structurally, not just by its name.

    A header alias is only a hint; the column must also be near-unique and
    near-complete. Date columns and amount columns are rejected outright.
    """

    row_count = len(frame)
    if row_count == 0:
        return None, "missing"

    best: tuple[float, str] | None = None
    for column in frame.columns:
        if column in exclude:
            continue
        values = frame[column].astype(str).str.strip()
        filled = values[values != ""]
        completeness = len(filled) / row_count
        if completeness < 0.99 or filled.empty:
            continue
        uniqueness = filled.nunique() / len(filled)
        if uniqueness < 0.95:
            continue
        if _looks_like_dates(filled):
            continue

        alias_bonus = 0.0
        if column == hinted:
            alias_bonus = 0.5
        elif _squash(column) in _NORMALIZED_ALIASES[ID_COLUMN]:
            alias_bonus = 0.5
        elif "id" in _norm(column).split() or _norm(column).endswith("id"):
            alias_bonus = 0.2

        score = uniqueness * completeness + alias_bonus
        if best is None or score > best[0]:
            best = (score, column)

    if best is None:
        return None, "missing"

    column = best[1]
    if column == hinted or _squash(column) in _NORMALIZED_ALIASES[ID_COLUMN]:
        return column, "high"
    return column, "medium"


def score_status_column(frame: pd.DataFrame, column: str) -> tuple[float, dict]:
    """How well does this column split the file into approved vs denied rows?"""

    values = frame[column].astype(str).str.strip()
    distinct = values[values != ""].unique()
    if not 2 <= len(distinct) <= 60:
        return 0.0, {}

    buckets = {value: classify_status_value(value) for value in distinct}
    approved_values = [v for v, b in buckets.items() if b == APPROVED]
    denied_values = [v for v, b in buckets.items() if b == DENIED]
    if not approved_values or not denied_values:
        return 0.0, {}

    classified = values.isin(approved_values + denied_values).mean()
    approved_rows = int(values.isin(approved_values).sum())
    denied_rows = int(values.isin(denied_values).sum())
    if approved_rows < 2 or denied_rows < 1:
        return 0.0, {}

    # Prefer a column that classifies most rows and keeps both classes usable.
    balance = min(approved_rows, denied_rows) / max(approved_rows, denied_rows)
    alias_bonus = 0.25 if _squash(column) in _NORMALIZED_ALIASES["Status"] else 0.0
    score = classified + 0.3 * balance + alias_bonus

    return score, {
        "approved_values": sorted(approved_values),
        "denied_values": sorted(denied_values),
        "unclassified_values": sorted(v for v, b in buckets.items() if b == UNKNOWN),
    }


def choose_status_columns(
    frame: pd.DataFrame,
    detected: dict[str, ColumnChoice],
    id_column: str | None,
) -> tuple[str | None, str | None, dict]:
    """Select the primary status column and an optional reason/sub-status column."""

    skip = {id_column} if id_column else set()
    ranked: list[tuple[float, str, dict]] = []
    for column in frame.columns:
        if column in skip:
            continue
        score, detail = score_status_column(frame, column)
        if score > 0:
            ranked.append((score, column, detail))

    if not ranked:
        return None, None, {}

    ranked.sort(key=lambda item: item[0], reverse=True)
    _, status_column, detail = ranked[0]

    # The reason column is whatever the alias table pointed at, as long as it is
    # not the column already chosen as the primary status.
    code_choice = detected["Status Code"].source
    if code_choice and code_choice != status_column:
        code_column = code_choice
    else:
        code_column = next(
            (
                column
                for _, column, _ in ranked[1:]
                if column != status_column
            ),
            None,
        )
        if code_column is None:
            code_column = next(
                (
                    column
                    for column in frame.columns
                    if column not in {status_column, id_column}
                    and _squash(column) in _NORMALIZED_ALIASES["Status Code"]
                ),
                None,
            )

    return status_column, code_column, detail


# --------------------------------------------------------------------------- #
# Adaptation
# --------------------------------------------------------------------------- #

@dataclass
class Adaptation:
    """Outcome of inspecting one uploaded CSV."""

    mode: str                                   # strict | adapted | insufficient
    frame: pd.DataFrame | None = None           # canonical frame (adapted only)
    id_lookup: dict[str, str] = field(default_factory=dict)
    report: dict = field(default_factory=dict)

    @property
    def usable(self) -> bool:
        return self.mode in {"strict", "adapted"}


def _is_strict(frame: pd.DataFrame) -> bool:
    """True when the file already matches the original hardcoded contract."""

    if not set(CANONICAL_COLUMNS).issubset(frame.columns):
        return False
    status = frame["Status"].astype(str).str.strip()
    code = frame["Status Code"].astype(str).str.strip()
    approved = (status == APPROVED_STATUS) & (code == APPROVED_STATUS_CODE)
    denied = status == DENIED_STATUS
    return bool(approved.sum() >= 2 and denied.sum() >= 1)


def _apply_override(
    detected: dict[str, ColumnChoice],
    override: dict | None,
    frame: pd.DataFrame,
    warnings: list[str],
) -> dict[str, ColumnChoice]:
    """Let an explicit column_map win over anything auto-detection inferred."""

    if not override:
        return detected
    column_map = override.get("column_map") or {}
    for canonical, source in column_map.items():
        if canonical not in detected:
            warnings.append(f"Ignored override for unknown field '{canonical}'.")
            continue
        if source is None:
            detected[canonical] = ColumnChoice(canonical, None, "missing")
            continue
        if source not in frame.columns:
            warnings.append(
                f"Override for '{canonical}' names column '{source}', "
                "which is not in the uploaded file; auto-detection kept."
            )
            continue
        detected[canonical] = ColumnChoice(canonical, source, "override")
    return detected


def _classify_rows(
    frame: pd.DataFrame,
    status_column: str,
    code_column: str | None,
    override: dict | None,
) -> tuple[pd.Series, pd.Series]:
    """Return per-row status class and an administrative-reason flag."""

    status_values = frame[status_column].astype(str).str.strip()
    status_map = (override or {}).get("status_map") or {}

    explicit_approved = {str(v).strip().lower() for v in status_map.get("approved", [])}
    explicit_denied = {str(v).strip().lower() for v in status_map.get("denied", [])}
    explicit_admin = {
        str(v).strip().lower() for v in status_map.get("admin_excluded", [])
    }

    def classify(value: str) -> str:
        lowered = value.strip().lower()
        if lowered in explicit_denied:
            return DENIED
        if lowered in explicit_approved:
            return APPROVED
        if explicit_approved or explicit_denied:
            # An explicit map is authoritative: anything unlisted stays unknown
            # only when the caller did not describe it at all.
            return classify_status_value(value)
        return classify_status_value(value)

    classes = status_values.map(classify)

    if code_column is not None and code_column in frame.columns:
        code_values = frame[code_column].astype(str).str.strip()
        admin = code_values.map(
            lambda value: value.strip().lower() in explicit_admin
            or is_admin_value(value)
        )
        # A reason column that clearly says "denied" overrides an ambiguous status.
        code_classes = code_values.map(classify_status_value)
        classes = classes.where(classes != UNKNOWN, code_classes)
        classes = classes.mask(
            (classes == APPROVED) & (code_classes == DENIED), DENIED
        )
    else:
        admin = status_values.map(
            lambda value: value.strip().lower() in explicit_admin
            or is_admin_value(value)
        )

    return classes, admin


def _fill_categorical(
    frame: pd.DataFrame,
    choice: ColumnChoice,
    warnings: list[str],
) -> pd.Series:
    if choice.source and choice.source in frame.columns:
        values = frame[choice.source].astype(str).str.strip()
        return values.replace("", UNKNOWN_CATEGORY)
    warnings.append(
        f"No '{choice.canonical}' column found; filled with "
        f"'{UNKNOWN_CATEGORY}' (reduces matching precision)."
    )
    return pd.Series([UNKNOWN_CATEGORY] * len(frame), index=frame.index)


def adapt(
    path: str | Path,
    override: dict | None = None,
    *,
    allow_strict: bool = True,
) -> Adaptation:
    """Inspect a CSV and produce a canonical frame the algorithms can consume."""

    raw = load_table(path)
    warnings: list[str] = []

    if allow_strict and not override and _is_strict(raw):
        return Adaptation(
            mode="strict",
            report={
                "mode": "strict",
                "id_column": {
                    "canonical": ID_COLUMN,
                    "source": ID_COLUMN,
                    "confidence": "high",
                },
                "column_mapping": {
                    name: {"source": name, "confidence": "high"}
                    for name in CANONICAL_COLUMNS
                },
                "status_mapping": {
                    "status_column": "Status",
                    "status_code_column": "Status Code",
                    "approved_values": [APPROVED_STATUS],
                    "denied_values": [DENIED_STATUS],
                    "admin_excluded_values": [],
                    "unclassified_values": [],
                },
                "row_counts": {},
                "unmapped_columns": [
                    c for c in raw.columns if c not in CANONICAL_COLUMNS
                ],
                "warnings": [],
            },
        )

    detected = detect_columns(raw)
    detected = _apply_override(detected, override, raw, warnings)

    # ---- identifier ------------------------------------------------------- #
    hinted_id = detected[ID_COLUMN].source
    override_id = ((override or {}).get("column_map") or {}).get(ID_COLUMN)
    if override_id and override_id in raw.columns:
        id_column, id_confidence = override_id, "override"
    else:
        reserved = {
            choice.source
            for name, choice in detected.items()
            if choice.source and name in {"Billed Amount", "Aging Days", "DOS",
                                          "Submitted Date"}
        }
        id_column, id_confidence = detect_id_column(raw, hinted_id, reserved)

    if id_column is None:
        return Adaptation(
            mode="insufficient",
            report={
                "mode": "insufficient",
                "reason": (
                    "No unique identifier column could be detected. A column of "
                    "distinct, non-empty claim/visit IDs is required to report "
                    "results."
                ),
                "id_column": {"canonical": ID_COLUMN, "source": None,
                              "confidence": "missing"},
                "column_mapping": {
                    name: {"source": c.source, "confidence": c.confidence}
                    for name, c in detected.items()
                },
                "status_mapping": {},
                "row_counts": {"total": len(raw)},
                "unmapped_columns": list(raw.columns),
                "warnings": warnings,
            },
        )

    # ---- status ----------------------------------------------------------- #
    override_status = ((override or {}).get("column_map") or {}).get("Status")
    if override_status and override_status in raw.columns:
        status_column = override_status
        code_column = detected["Status Code"].source
        _, detail = score_status_column(raw, status_column)
    else:
        status_column, code_column, detail = choose_status_columns(
            raw, detected, id_column
        )

    if status_column is None:
        return Adaptation(
            mode="insufficient",
            report={
                "mode": "insufficient",
                "reason": (
                    "No status column containing both approved-like values "
                    "(paid / approved / claim in process) and denied-like values "
                    "(denied / rejected / not paid) could be detected."
                ),
                "id_column": {"canonical": ID_COLUMN, "source": id_column,
                              "confidence": id_confidence},
                "column_mapping": {
                    name: {"source": c.source, "confidence": c.confidence}
                    for name, c in detected.items()
                },
                "status_mapping": {},
                "row_counts": {"total": len(raw)},
                "unmapped_columns": [
                    c for c in raw.columns if c != id_column
                ],
                "warnings": warnings,
            },
        )

    classes, admin = _classify_rows(raw, status_column, code_column, override)

    # A row whose reason column reports a submission defect is not a clean
    # reference claim, mirroring the original Status AND Status Code conjunction.
    approved_mask = (classes == APPROVED) & ~admin
    denied_mask = classes == DENIED
    approved_count = int(approved_mask.sum())
    denied_count = int(denied_mask.sum())
    candidate_count = int((denied_mask & ~admin).sum())

    if approved_count < 2 or denied_count < 1:
        return Adaptation(
            mode="insufficient",
            report={
                "mode": "insufficient",
                "reason": (
                    f"Column '{status_column}' yielded {approved_count} "
                    f"approved-like and {denied_count} denied-like rows. Both "
                    "classes are required to find approved twins for denied "
                    "claims."
                ),
                "id_column": {"canonical": ID_COLUMN, "source": id_column,
                              "confidence": id_confidence},
                "column_mapping": {
                    name: {"source": c.source, "confidence": c.confidence}
                    for name, c in detected.items()
                },
                "status_mapping": {
                    "status_column": status_column,
                    "status_code_column": code_column,
                    **detail,
                },
                "row_counts": {
                    "total": len(raw),
                    "approved": approved_count,
                    "denied": denied_count,
                },
                "unmapped_columns": [],
                "warnings": warnings,
            },
        )

    # ---- build the canonical frame ---------------------------------------- #
    canonical = pd.DataFrame(index=raw.index)

    # Identifiers travel as opaque surrogates so pandas cannot reformat them on
    # re-read; the caller swaps the originals back in before responding.
    original_ids = raw[id_column].astype(str).str.strip()
    surrogates = pd.Series(
        [f"GDID{index:08d}" for index in range(len(raw))], index=raw.index
    )
    id_lookup = dict(zip(surrogates, original_ids))
    canonical[ID_COLUMN] = surrogates

    status_out = pd.Series([OTHER_STATUS] * len(raw), index=raw.index)
    status_out = status_out.mask(approved_mask, APPROVED_STATUS)
    status_out = status_out.mask(denied_mask, DENIED_STATUS)
    canonical["Status"] = status_out

    if code_column and code_column in raw.columns:
        raw_codes = raw[code_column].astype(str).str.strip()
    else:
        raw_codes = pd.Series([""] * len(raw), index=raw.index)
        warnings.append(
            "No reason / sub-status column found; administrative denials cannot "
            "be excluded from the candidate pool."
        )

    code_out = raw_codes.replace("", DEFAULT_DENIED_CODE)
    code_out = code_out.mask(approved_mask, APPROVED_STATUS_CODE)
    # Administrative denials must carry a literal the algorithms exclude on.
    code_out = code_out.mask(denied_mask & admin, ADMIN_CANONICAL_CODE)
    # Guard against a non-admin reason coincidentally equalling an excluded one.
    collision = denied_mask & ~admin & code_out.isin(
        {"Incorrect Submission", "Provider Info Missing", "Claim not on file"}
    )
    code_out = code_out.mask(collision, DEFAULT_DENIED_CODE)
    canonical["Status Code"] = code_out

    action = detected["Action Code"]
    if action.source and action.source in raw.columns:
        canonical["Action Code"] = (
            raw[action.source].astype(str).str.strip().replace("", UNKNOWN_CATEGORY)
        )
    else:
        canonical["Action Code"] = UNKNOWN_CATEGORY

    for name in ("Insurance Name", "Primary/Secondary", "Client"):
        canonical[name] = _fill_categorical(raw, detected[name], warnings)

    # ---- dates ------------------------------------------------------------ #
    dos_choice = detected["DOS"].source
    submitted_choice = detected["Submitted Date"].source

    # One convention for the whole file: parsing DOS as mm/dd and the submitted
    # date as dd/mm would manufacture negative filing delays.
    dayfirst = infer_dayfirst(
        [raw[c] for c in (dos_choice, submitted_choice) if c and c in raw.columns]
    )
    if dayfirst:
        warnings.append("Dates read as day-first (dd/mm/yyyy).")

    dos = (
        to_datetime(raw[dos_choice], dayfirst)
        if dos_choice
        else pd.Series(pd.NaT, index=raw.index)
    )
    submitted = (
        to_datetime(raw[submitted_choice], dayfirst)
        if submitted_choice
        else pd.Series(pd.NaT, index=raw.index)
    )

    if dos_choice is None and submitted_choice is None:
        warnings.append(
            "No service or submission date column found; filing delay is treated "
            "as zero for every row."
        )
        dos = pd.Series([FALLBACK_DATE] * len(raw), index=raw.index)
        submitted = dos.copy()
    elif dos_choice is None:
        warnings.append("No date-of-service column found; submission date reused.")
        dos = submitted.copy()
    elif submitted_choice is None:
        warnings.append("No submission date column found; date of service reused.")
        submitted = dos.copy()

    # Never let NaT through: exact_match casts filing delay with int().
    anchor = dos.dropna().median() if dos.notna().any() else FALLBACK_DATE
    dos = dos.fillna(anchor)
    submitted = submitted.fillna(dos)
    unparsed = int((submitted < dos).sum())
    if unparsed:
        warnings.append(
            f"{unparsed} row(s) have a submission date before the service date; "
            "filing delay clamped to zero for those rows."
        )
        submitted = submitted.where(submitted >= dos, dos)

    canonical["DOS"] = dos.dt.strftime("%Y-%m-%d")
    canonical["Submitted Date"] = submitted.dt.strftime("%Y-%m-%d")

    # ---- numerics --------------------------------------------------------- #
    amount_choice = detected["Billed Amount"].source
    if amount_choice and amount_choice in raw.columns:
        amount = to_number(raw[amount_choice])
        if amount.notna().mean() < 0.5:
            warnings.append(
                f"Column '{amount_choice}' did not parse as currency for most "
                "rows; unparsed values replaced with the column median."
            )
        amount = amount.fillna(amount.median() if amount.notna().any() else 0.0)
    else:
        warnings.append(
            "No billed-amount column found; amount treated as 0 for every row "
            "(amount-based similarity is disabled)."
        )
        amount = pd.Series([0.0] * len(raw), index=raw.index)
    canonical["Billed Amount"] = amount.astype(float)

    aging_choice = detected["Aging Days"].source
    if aging_choice and aging_choice in raw.columns:
        aging = to_number(raw[aging_choice])
        aging = aging.fillna(aging.median() if aging.notna().any() else 0.0)
    else:
        reference = submitted.max()
        aging = (reference - submitted).dt.days.astype(float)
        warnings.append(
            "No aging-days column found; derived from the newest submission date."
        )
    canonical["Aging Days"] = aging.astype(float)

    canonical = canonical[CANONICAL_COLUMNS]

    report = {
        "mode": "adapted",
        "id_column": {
            "canonical": ID_COLUMN,
            "source": id_column,
            "confidence": id_confidence,
        },
        "column_mapping": {
            name: {
                "source": (
                    id_column if name == ID_COLUMN
                    else status_column if name == "Status"
                    else code_column if name == "Status Code"
                    else detected[name].source
                ),
                "confidence": (
                    id_confidence if name == ID_COLUMN
                    else "high" if name in {"Status", "Status Code"}
                    and (status_column if name == "Status" else code_column)
                    else detected[name].confidence
                ),
            }
            for name in CANONICAL_COLUMNS
        },
        "status_mapping": {
            "status_column": status_column,
            "status_code_column": code_column,
            **detail,
        },
        "row_counts": {
            "total": int(len(raw)),
            "approved": approved_count,
            "denied": denied_count,
            "denied_candidates": candidate_count,
            "administrative_excluded": int((denied_mask & admin).sum()),
            "unclassified": int((classes == UNKNOWN).sum()),
        },
        "unmapped_columns": [
            column
            for column in raw.columns
            if column
            not in {
                id_column, status_column, code_column,
                *(c.source for c in detected.values() if c.source),
            }
        ],
        "warnings": warnings,
    }

    return Adaptation(
        mode="adapted", frame=canonical, id_lookup=id_lookup, report=report
    )


def restore_ids(values: list[str], lookup: dict[str, str]) -> list[str]:
    """Swap surrogate keys back to the identifiers as they appear in the CSV."""

    if not lookup:
        return [str(value) for value in values]
    return [str(lookup.get(str(value), value)) for value in values]


def preview(path: str | Path, override: dict | None = None) -> dict:
    """Report the inferred schema without running any algorithm."""

    adaptation = adapt(path, override, allow_strict=override is None)
    report = dict(adaptation.report)

    if adaptation.mode == "strict":
        raw = load_table(path)
        status = raw["Status"].astype(str).str.strip()
        code = raw["Status Code"].astype(str).str.strip()
        approved = (status == APPROVED_STATUS) & (code == APPROVED_STATUS_CODE)
        denied = status == DENIED_STATUS
        report["row_counts"] = {
            "total": int(len(raw)),
            "approved": int(approved.sum()),
            "denied": int(denied.sum()),
        }
        report["id_sample"] = raw[ID_COLUMN].astype(str).head(5).tolist()
    elif adaptation.mode == "adapted":
        report["id_sample"] = list(adaptation.id_lookup.values())[:5]

    return report
