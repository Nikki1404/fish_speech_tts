import io
import json
from pathlib import Path

import pandas as pd
import pytest
from fastapi.testclient import TestClient

import schema_adapter
from app import app

client = TestClient(app)

BASE_DIR = Path(__file__).resolve().parent
SAMPLES = BASE_DIR / "sample_csvs"

RESULT_KEYS = ["exact_match", "logistic_regression", "k-NN"]


def upload(path: Path, endpoint: str = "/audit/upload", **form):
    with path.open("rb") as handle:
        return client.post(
            endpoint,
            files={"file": (path.name, handle, "text/csv")},
            data=form,
        )


def test_health() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_combined_audit_shape() -> None:
    response = client.post("/audit", json={"max_items": 2})
    assert response.status_code == 200, response.text
    payload = response.json()
    for key in RESULT_KEYS:
        assert isinstance(payload[key], list)
        assert len(payload[key]) <= 2


def test_bundled_dataset_uses_strict_mode() -> None:
    """The original schema must bypass adaptation entirely."""

    response = client.post("/audit", json={})
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["schema_report"]["mode"] == "strict"
    assert len(payload["exact_match"]) == 6
    assert len(payload["logistic_regression"]) == 3
    assert len(payload["k-NN"]) == 16


# --------------------------------------------------------------------------- #
# Schema adaptation
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize(
    "filename, expected_id_column",
    [
        ("variant_a_payer_export.csv", "Claim Number"),
        ("variant_b_minimal.csv", "Claim ID"),
        ("variant_c_messy.csv", "Acct No"),
    ],
)
def test_unfamiliar_schemas_are_adapted(filename, expected_id_column) -> None:
    path = SAMPLES / filename
    if not path.exists():
        pytest.skip(f"{filename} not generated")

    response = upload(path)
    assert response.status_code == 200, response.text
    payload = response.json()
    report = payload["schema_report"]

    assert report["mode"] == "adapted"
    assert report["id_column"]["source"] == expected_id_column
    assert any(payload[key] for key in RESULT_KEYS)


def test_returned_ids_come_from_the_uploaded_file() -> None:
    """Results must be real identifiers from the CSV, not row numbers."""

    path = SAMPLES / "variant_a_payer_export.csv"
    if not path.exists():
        pytest.skip("sample not generated")

    source_ids = set(pd.read_csv(path, dtype=str)["Claim Number"])
    payload = upload(path).json()
    returned = {value for key in RESULT_KEYS for value in payload[key]}

    assert returned
    assert returned <= source_ids


def test_leading_zero_identifiers_survive_the_round_trip() -> None:
    path = SAMPLES / "variant_c_messy.csv"
    if not path.exists():
        pytest.skip("sample not generated")

    payload = upload(path).json()
    returned = [value for key in RESULT_KEYS for value in payload[key]]

    assert returned
    assert all(value.startswith("0") and len(value) == 9 for value in returned)


def test_single_class_file_degrades_instead_of_failing() -> None:
    path = SAMPLES / "variant_d_denials_only.csv"
    if not path.exists():
        pytest.skip("sample not generated")

    response = upload(path)
    assert response.status_code == 200, response.text
    payload = response.json()

    assert all(payload[key] == [] for key in RESULT_KEYS)
    assert payload["schema_report"]["mode"] == "insufficient"
    assert payload["schema_report"]["reason"]


def test_unusable_csv_reports_a_reason_rather_than_500() -> None:
    content = b"alpha,beta\n1,2\n3,4\n"
    response = client.post(
        "/audit/upload",
        files={"file": ("junk.csv", io.BytesIO(content), "text/csv")},
    )
    assert response.status_code == 200, response.text
    payload = response.json()
    assert payload["schema_report"]["mode"] == "insufficient"
    assert all(payload[key] == [] for key in RESULT_KEYS)


def test_non_csv_upload_is_rejected() -> None:
    response = client.post(
        "/audit/upload",
        files={"file": ("notes.txt", io.BytesIO(b"hello"), "text/plain")},
    )
    assert response.status_code == 400


# --------------------------------------------------------------------------- #
# Preview and override
# --------------------------------------------------------------------------- #

def test_schema_preview_runs_no_algorithms() -> None:
    path = SAMPLES / "variant_a_payer_export.csv"
    if not path.exists():
        pytest.skip("sample not generated")

    response = upload(path, endpoint="/schema/preview")
    assert response.status_code == 200, response.text
    report = response.json()

    assert report["mode"] == "adapted"
    assert report["id_column"]["source"] == "Claim Number"
    assert report["status_mapping"]["status_column"] == "Claim Status"
    assert "Paid" in report["status_mapping"]["approved_values"]
    assert "Rejected" in report["status_mapping"]["denied_values"]
    assert len(report["id_sample"]) > 0
    assert not any(key in report for key in RESULT_KEYS)


def test_column_override_wins_over_detection() -> None:
    path = SAMPLES / "variant_a_payer_export.csv"
    if not path.exists():
        pytest.skip("sample not generated")

    override = json.dumps({"column_map": {"VisitID#": "Patient"}})
    report = upload(path, endpoint="/schema/preview", schema_override=override).json()
    assert report["id_column"]["source"] == "Patient"
    assert report["id_column"]["confidence"] == "override"


def test_status_override_reclassifies_values() -> None:
    path = SAMPLES / "variant_a_payer_export.csv"
    if not path.exists():
        pytest.skip("sample not generated")

    override = json.dumps(
        {"status_map": {"approved": ["Paid"], "denied": ["Rejected", "Pending"]}}
    )
    payload = upload(path, schema_override=override).json()
    counts = payload["schema_report"]["row_counts"]
    # 49 rejected + 37 pending now count as denied.
    assert counts["denied"] == 86


def test_malformed_override_is_rejected() -> None:
    path = SAMPLES / "variant_a_payer_export.csv"
    if not path.exists():
        pytest.skip("sample not generated")

    response = upload(path, schema_override="{not json")
    assert response.status_code == 400


# --------------------------------------------------------------------------- #
# Adapter units
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize(
    "value, expected",
    [
        ("Paid", schema_adapter.APPROVED),
        ("Approved", schema_adapter.APPROVED),
        ("Claim in Process", schema_adapter.APPROVED),
        ("Claim at insurance", schema_adapter.APPROVED),
        ("Denied", schema_adapter.DENIED),
        ("Rejected", schema_adapter.DENIED),
        ("Not Paid", schema_adapter.DENIED),      # must not match "paid"
        ("Non-Payment", schema_adapter.DENIED),
        ("Unpaid", schema_adapter.DENIED),
        ("Pending", schema_adapter.UNKNOWN),
        ("", schema_adapter.UNKNOWN),
    ],
)
def test_status_vocabulary(value, expected) -> None:
    assert schema_adapter.classify_status_value(value) == expected


@pytest.mark.parametrize(
    "value, expected",
    [("$1,234.50", 1234.50), ("(123.45)", -123.45), ("1234", 1234.0), ("n/a", None)],
)
def test_currency_parsing(value, expected) -> None:
    result = schema_adapter.to_number(pd.Series([value])).iloc[0]
    if expected is None:
        assert pd.isna(result)
    else:
        assert result == pytest.approx(expected)


def test_dayfirst_inference() -> None:
    dayfirst = pd.Series(["27/12/2024", "13/01/2025", "05/06/2024"])
    monthfirst = pd.Series(["12/27/2024", "01/13/2025", "06/05/2024"])
    assert schema_adapter.infer_dayfirst([dayfirst]) is True
    assert schema_adapter.infer_dayfirst([monthfirst]) is False
