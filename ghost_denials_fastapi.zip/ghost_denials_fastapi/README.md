# Ghost Denials FastAPI

This API wraps three separate candidate-generation methods:

1. Exact equivalence-class matching
2. Logistic-regression propensity matching
3. k-nearest-neighbor approved-twin retrieval

Each one looks for denied claims that closely resemble claims the payer did *not*
deny — "ghost denials" that arguably should have been paid.

Uploaded CSVs **do not have to use the bundled dataset's column names or status
wording**. Unfamiliar files are mapped onto the canonical schema automatically and
the mapping is reported back with the results. See
[Working with other CSV layouts](#working-with-other-csv-layouts).

## Proxy label used

A row is treated as a proxy-approved/reference claim only when:

```text
Status = Claim at insurance
AND Status Code = Claim in Process
```

A candidate is a row with `Status = Denied`, excluding configured
administrative/incomplete-submission status codes.

## Response

```json
{
  "exact_match": ["denied claim id"],
  "logistic_regression": ["denied claim id"],
  "k-NN": ["denied claim id"],
  "schema_report": { "mode": "strict" }
}
```

The three lists contain identifiers **exactly as they appear in the uploaded
file**. `schema_report` is additive — consumers that only read the three lists are
unaffected.

## Install and run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

Windows activation:

```powershell
.venv\Scripts\activate
```

Swagger UI:

```text
http://127.0.0.1:8000/docs
```

### Browser origins

The React app calls this API cross-origin, so its origin must be in the CORS
allow-list. Ports `5173-5175` and `4173-4175` on `localhost` and `127.0.0.1` are
allowed: Vite walks forward from its default port when one is already in use, and
without the fallbacks in the list a bumped port turns every request into an opaque
CORS failure instead of an obvious "port in use" message. Add your own origin in
`app.py` if you serve the frontend from somewhere else.

## Run with bundled dataset

```bash
curl -X POST http://127.0.0.1:8000/audit \
  -H "Content-Type: application/json" \
  -d '{}'
```

Optional settings:

```bash
curl -X POST http://127.0.0.1:8000/audit \
  -H "Content-Type: application/json" \
  -d '{
    "logistic_caliper_multiplier": 0.20,
    "knn_control_quantile": 0.75,
    "max_items": 10
  }'
```

## Upload a CSV

```bash
curl -X POST http://127.0.0.1:8000/audit/upload \
  -F "file=@claims.csv" \
  -F "logistic_caliper_multiplier=0.20" \
  -F "knn_control_quantile=0.75"
```

---

## Working with other CSV layouts

`schema_adapter.py` sits in front of the three algorithms. It inspects an uploaded
file, works out which column holds the unique identifier, which holds the claim
status and which holds the reason, then rewrites the file into the canonical
schema. **The algorithm modules are never modified and never see the original
layout.**

### The three modes

| `schema_report.mode` | Meaning |
| --- | --- |
| `strict` | The file already matches the canonical schema and vocabulary. Used untouched — results are bit-for-bit identical to the pre-adapter behaviour. |
| `adapted` | A mapping was inferred (or supplied). A canonical copy is built in a temp file and discarded afterwards. |
| `insufficient` | No usable identifier, or only one of the two classes is present. Returns HTTP 200 with empty lists and a `reason`, never a 500. |

### Column detection

Headers are normalised (case, spaces and punctuation folded away) and matched
against an alias table, then by fuzzy similarity. Recognised aliases include:

| Canonical | Recognised as |
| --- | --- |
| `VisitID#` | claim id, claim number, encounter id, account no, invoice, ICN, DCN, … |
| `Status` | claim status, current status, payment status, disposition, outcome, … |
| `Status Code` | sub status, reason code, denial reason, CARC, remark code, … |
| `Billed Amount` | charge amount, total charges, claim amount, billed, … |
| `Aging Days` | age, days outstanding, AR days, days in AR, … |
| `DOS` | date of service, service date, svc date, encounter date, … |
| `Submitted Date` | submission date, date filed, billed date, claim date, … |
| `Insurance Name` | payer, payor, carrier, plan name, … |
| `Primary/Secondary` | coverage level, payer sequence, COB, insurance type, … |
| `Client` | facility, practice, provider group, location, … |

The identifier is chosen **structurally, not just by name**: a candidate column
must be ≥95% distinct and ≥99% populated, and must not parse as dates. A matching
header name is only a tie-breaker.

### Status vocabulary

Every column with 2–60 distinct values is scored on how cleanly it splits the file
into approved-like and denied-like rows; the best-scoring column wins.

| Bucket | Matched words |
| --- | --- |
| approved | paid, approved, allowed, adjudicated, settled, accepted, claimed, claim in process, in process, at insurance, with payer, under review, … |
| denied | denied, denial, rejected, not paid, unpaid, non-payment, refused, disallowed, non-covered, write-off, … |
| administrative | incorrect submission, provider info missing, claim not on file, missing information, incomplete, needs correction, resubmit, registration error |

Denied is tested **before** approved so that `Not Paid` and `Non-Covered` are not
caught by the `paid`/`covered` patterns.

Administrative rows are denials that were never validly submitted; they are
excluded from the candidate pool, mirroring `ADMIN_EXCLUSION_STATUS_CODES`. The
list is deliberately narrow — eligibility, coverage and medical-necessity denials
are substantive payer decisions and stay in the pool. Widen it per request with
`status_map.admin_excluded` if your workflow disagrees.

Values matching nothing are simply unclassified and take no part in the analysis.
They are listed in `schema_report.status_mapping.unclassified_values` so you can
see what was ignored.

### Filling gaps

| Missing | Behaviour |
| --- | --- |
| `Insurance Name`, `Client`, `Primary/Secondary` | filled with `UNKNOWN`; blocking degenerates to no blocking |
| `Billed Amount` | treated as 0; amount-based similarity disabled |
| `Aging Days` | derived from the newest submission date |
| one date column | the other is reused, so filing delay is 0 |
| both date columns | a constant date is used |

Every substitution appends a line to `schema_report.warnings`. Results are still
returned, but a file reduced to an ID and a status has little for the algorithms
to match on — read the warnings before trusting adapted output.

### Values that pandas would otherwise corrupt

- Identifiers travel through the pipeline as opaque surrogate keys and are swapped
  back before the response, so `0012345` does not become `12345`, and a numeric ID
  column containing one blank does not turn every value into `100234.0`.
- Amounts accept `$1,234.50` and `(123.45)` (parenthesised negatives).
- Day-first vs month-first is decided **once for the whole file** using evidence
  from every date column. Deciding per value lets one file parse two ways and
  silently produces negative filing delays.
- Delimiter (`,` `;` tab `|`), BOM, encoding (UTF-8/CP1252/Latin-1) and
  spreadsheet preamble rows above the real header are all detected.

### Partial results

Datasets can satisfy one algorithm and starve another — k-NN needs at least two
approved controls inside a blocking group, logistic regression needs both classes
in every CV fold. A failing algorithm returns an empty list and appends an
explanation to `schema_report.warnings` instead of failing the whole request.

## Preview the mapping before running

`POST /schema/preview` reports how a file would be read **without running any
algorithm** — no scikit-learn work, so it returns immediately.

```bash
curl -X POST http://127.0.0.1:8000/schema/preview -F "file=@my_export.csv"
```

```json
{
  "mode": "adapted",
  "id_column": { "canonical": "VisitID#", "source": "Claim Number", "confidence": "high" },
  "status_mapping": {
    "status_column": "Claim Status",
    "status_code_column": "Denial Reason",
    "approved_values": ["Paid"],
    "denied_values": ["Rejected"],
    "unclassified_values": ["Awaiting Response", "Error", "Pending"]
  },
  "row_counts": { "total": 200, "approved": 45, "denied": 49, "denied_candidates": 35 },
  "id_sample": ["12537E269279", "28622N030427"],
  "warnings": []
}
```

## Overriding the mapping

Both `/audit/upload` and `/schema/preview` accept an optional `schema_override`
form field containing JSON. Anything you do not mention stays auto-detected.

```bash
curl -X POST http://127.0.0.1:8000/audit/upload \
  -F "file=@my_export.csv" \
  -F 'schema_override={
        "column_map": { "VisitID#": "Claim Number", "Client": "Facility Code" },
        "status_map": {
          "approved": ["Paid", "In Process"],
          "denied":   ["Rejected", "Void"],
          "admin_excluded": ["Missing Info"]
        }
      }'
```

- `column_map` — canonical field → the column in *your* file. `null` drops a field.
- `status_map` — raw values → bucket. Explicit values win over the keyword lists.

## Sample datasets

`sample_csvs/` holds four files derived from `claims.csv`, all describing the same
200 claims through different schemas:

| File | Exercises |
| --- | --- |
| `variant_a_payer_export.csv` | every column renamed, `Paid`/`Rejected` wording, `$1,234.50` amounts |
| `variant_b_minimal.csv` | ID + status + amount only; everything else synthesised |
| `variant_c_messy.csv` | semicolon-delimited, BOM, 3 preamble rows, `dd/mm/yyyy` dates, `000000041` IDs |
| `variant_d_denials_only.csv` | denials with no approved rows — must degrade, not crash |

Variants A and C return **identical claim sets**, which is the point: the same
claims are recovered from a clean export and from a hostile one.

## Tests

```bash
pip install pytest httpx
pytest test_api.py -q
```

Covers the strict-mode regression baseline (6 / 3 / 16 on `claims.csv`), adaptation
across all four variants, identifier round-tripping, the status vocabulary, the
currency and date parsers, preview, and overrides.

## Docker

```bash
docker build -t ghost-denials-api .
docker run --rm -p 8000:8000 ghost-denials-api
```

## Notes

- `Status`, `Status Code`, `Action Code`, assignment fields, follow-up date, and AR notes are not prediction features.
- Action Code is retained by the individual algorithm modules only for evidence/routing.
- The public FastAPI response contains item-ID lists plus the additive `schema_report`.
- This dataset supports a proxy similarity POC, not appeal-overturn or conformal false-positive validation.
- In `adapted` mode the approved class is "status reads as approved and the reason is not administrative", which is slightly broader than the strict `Status AND Status Code` literal pair. Exact-match and k-NN results stay stable under that change; logistic regression is a *learned* model, so a larger reference pool shifts its propensity scores and its output moves more. Compare adapted runs against each other, not against strict runs.
