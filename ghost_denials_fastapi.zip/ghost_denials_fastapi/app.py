#!/usr/bin/env python3
"""FastAPI wrapper for the three Ghost Denials candidate generators.

Proxy-approved definition used by all algorithms:
    Status == "Claim at insurance"
    AND Status Code == "Claim in Process"

Candidate population:
    Status == "Denied"
    excluding clearly administrative/incomplete-submission status codes.

Uploaded CSVs that do not use those exact column names or that exact status
vocabulary are passed through `schema_adapter` first, which infers the unique
identifier column, the status column and the reason column, then rewrites the
file into the canonical schema. The algorithm modules are untouched.

The public response contains the denied identifiers exactly as they appear in
the uploaded file:
{
    "exact_match": [...],
    "logistic_regression": [...],
    "k-NN": [...],
    "schema_report": {...}
}
"""

from __future__ import annotations

import json
import shutil
import tempfile
from pathlib import Path
from threading import Lock
from typing import Any, Callable

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, Field, field_validator

import schema_adapter
from exact_match import run_exact_match
from logistic_regression import run_propensity_matching
from knn import run_knn

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_DATA_PATH = BASE_DIR / "claims.csv"

# Scikit-learn jobs are small for this dataset, but the lock prevents several
# simultaneous requests from repeating CPU-heavy cross-validation needlessly.
AUDIT_LOCK = Lock()

app = FastAPI(
    title="Ghost Denials Audit API",
    version="1.1.0",
    description=(
        "Runs exact equivalence matching, logistic-regression propensity "
        "matching, and k-nearest-neighbor approved-twin retrieval. Uploaded "
        "CSVs with unfamiliar column names or status wording are mapped onto "
        "the canonical schema automatically."
    ),
)

# Allow the Vite dev server (and other local origins) to call this API from the
# browser. Without this, cross-origin fetch() from the React app is blocked.
# Vite walks forward from its default port when one is already taken, so the
# next few ports are allowed too - otherwise a fallback silently breaks every
# request with a CORS error rather than an obvious "port in use" message.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        f"http://{host}:{port}"
        for host in ("localhost", "127.0.0.1")
        for port in (5173, 5174, 5175, 4173, 4174, 4175)
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)


class AuditRequest(BaseModel):
    """Optional algorithm settings for the bundled claims.csv dataset."""

    logistic_caliper_multiplier: float = Field(default=0.20, gt=0, le=2.0)
    knn_control_quantile: float = Field(default=0.75, gt=0, lt=1)
    max_items: int | None = Field(default=None, gt=0)


class AuditResponse(BaseModel):
    """Exact response shape required by the consumer.

    `schema_report` is additive: existing consumers that only read the three
    lists keep working unchanged.
    """

    model_config = ConfigDict(populate_by_name=True)

    exact_match: list[str]
    logistic_regression: list[str]
    k_nn: list[str] = Field(alias="k-NN")
    schema_report: dict[str, Any] | None = None

    @field_validator("exact_match", "logistic_regression", "k_nn")
    @classmethod
    def unique_ids(cls, values: list[str]) -> list[str]:
        # Preserve algorithm ranking/order while removing accidental duplicates.
        return list(dict.fromkeys(str(value) for value in values))


def _limit(values: list[str], max_items: int | None) -> list[str]:
    return values if max_items is None else values[:max_items]


def _parse_override(raw: str | None) -> dict | None:
    """Parse the optional schema_override form field."""

    if raw is None or not raw.strip():
        return None
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=400,
            detail=f"schema_override is not valid JSON: {exc.msg}",
        ) from exc
    if not isinstance(parsed, dict):
        raise HTTPException(
            status_code=400,
            detail="schema_override must be a JSON object.",
        )
    return parsed


def _run_safely(
    name: str,
    runner: Callable[[], list[str]],
    warnings: list[str],
) -> list[str]:
    """Run one algorithm; degrade to an empty list instead of failing the request.

    A dataset can satisfy one algorithm and starve another (k-NN needs at least
    two approved controls inside a blocking group, logistic regression needs both
    classes in every CV fold). Returning partial results with an explanation is
    more useful than a 500 for the whole audit.
    """

    try:
        return runner()
    except Exception as exc:  # noqa: BLE001 - reported to the caller verbatim
        warnings.append(f"{name} could not run on this dataset: {exc}")
        return []


def run_all_algorithms(
    data_path: str | Path,
    *,
    logistic_caliper_multiplier: float = 0.20,
    knn_control_quantile: float = 0.75,
    max_items: int | None = None,
    schema_override: dict | None = None,
) -> AuditResponse:
    """Adapt the dataset if needed, then run all three algorithms."""

    path = Path(data_path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")

    adaptation = schema_adapter.adapt(
        path, schema_override, allow_strict=schema_override is None
    )

    if not adaptation.usable:
        # Nothing to match on - answer with empty lists and the reason why.
        return AuditResponse(
            exact_match=[],
            logistic_regression=[],
            k_nn=[],
            schema_report=adaptation.report,
        )

    report = dict(adaptation.report)
    warnings: list[str] = list(report.get("warnings", []))

    temporary_canonical: Path | None = None
    try:
        if adaptation.mode == "adapted":
            with tempfile.NamedTemporaryFile(
                mode="w",
                suffix=".csv",
                delete=False,
                newline="",
                encoding="utf-8",
            ) as handle:
                adaptation.frame.to_csv(handle, index=False)
                temporary_canonical = Path(handle.name)
            run_path = temporary_canonical
        else:
            run_path = path

        with AUDIT_LOCK:
            exact_ids = _run_safely(
                "Exact match",
                lambda: run_exact_match(str(run_path))[0]["exact_match"],
                warnings,
            )
            logistic_ids = _run_safely(
                "Logistic regression",
                lambda: run_propensity_matching(
                    str(run_path),
                    caliper_multiplier=logistic_caliper_multiplier,
                )[0]["logistic_regression"],
                warnings,
            )
            knn_ids = _run_safely(
                "k-NN",
                lambda: run_knn(
                    str(run_path),
                    control_quantile=knn_control_quantile,
                )[0]["k-NN"],
                warnings,
            )
    finally:
        if temporary_canonical is not None:
            temporary_canonical.unlink(missing_ok=True)

    lookup = adaptation.id_lookup
    report["warnings"] = warnings

    return AuditResponse(
        exact_match=_limit(schema_adapter.restore_ids(exact_ids, lookup), max_items),
        logistic_regression=_limit(
            schema_adapter.restore_ids(logistic_ids, lookup), max_items
        ),
        k_nn=_limit(schema_adapter.restore_ids(knn_ids, lookup), max_items),
        schema_report=report,
    )


def _save_upload(file: UploadFile) -> Path:
    """Persist an uploaded CSV to a temporary path."""

    filename = file.filename or "claims.csv"
    if not filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files are accepted.")

    with tempfile.NamedTemporaryFile(
        mode="wb",
        suffix=".csv",
        delete=False,
    ) as temporary_file:
        shutil.copyfileobj(file.file, temporary_file)
        return Path(temporary_file.name)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post(
    "/audit",
    response_model=AuditResponse,
    response_model_by_alias=True,
)
def audit(request: AuditRequest | None = None) -> AuditResponse:
    """Run all algorithms on the bundled claims.csv dataset."""

    params = request or AuditRequest()
    try:
        return run_all_algorithms(
            DEFAULT_DATA_PATH,
            logistic_caliper_multiplier=params.logistic_caliper_multiplier,
            knn_control_quantile=params.knn_control_quantile,
            max_items=params.max_items,
        )
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Audit failed: {exc}",
        ) from exc


@app.post(
    "/audit/upload",
    response_model=AuditResponse,
    response_model_by_alias=True,
)
def audit_uploaded_csv(
    file: UploadFile = File(..., description="AR claims CSV"),
    logistic_caliper_multiplier: float = Form(default=0.20, gt=0, le=2.0),
    knn_control_quantile: float = Form(default=0.75, gt=0, lt=1),
    max_items: int | None = Form(default=None, gt=0),
    schema_override: str | None = Form(
        default=None,
        description=(
            'Optional JSON, e.g. {"column_map": {"VisitID#": "Claim Number"}, '
            '"status_map": {"approved": ["Paid"], "denied": ["Rejected"]}}'
        ),
    ),
) -> AuditResponse:
    """Upload a CSV and run all three algorithms against it.

    Column names and status wording do not have to match the bundled dataset;
    unfamiliar schemas are mapped automatically and reported back in
    `schema_report`.
    """

    override = _parse_override(schema_override)
    temporary_path: Path | None = None
    try:
        temporary_path = _save_upload(file)
        return run_all_algorithms(
            temporary_path,
            logistic_caliper_multiplier=logistic_caliper_multiplier,
            knn_control_quantile=knn_control_quantile,
            max_items=max_items,
            schema_override=override,
        )
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Audit failed: {exc}",
        ) from exc
    finally:
        file.file.close()
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)


@app.post("/schema/preview")
def schema_preview(
    file: UploadFile = File(..., description="AR claims CSV"),
    schema_override: str | None = Form(default=None),
) -> dict[str, Any]:
    """Report how a CSV would be interpreted, without running any algorithm.

    Cheap and fast: no scikit-learn work happens here. Use it to confirm the
    detected identifier and status columns before committing to a full audit.
    """

    override = _parse_override(schema_override)
    temporary_path: Path | None = None
    try:
        temporary_path = _save_upload(file)
        return schema_adapter.preview(temporary_path, override)
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Schema preview failed: {exc}",
        ) from exc
    finally:
        file.file.close()
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=False)
